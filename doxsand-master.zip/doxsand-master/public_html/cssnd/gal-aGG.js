//Elaborado por: Abelardo Gándara González 2015
function mostrarGaleria(){
     document.getElementById('tablas').style.display = 'none';
     document.getElementById('galeria').style.display = 'block';
     document.getElementById('verGaleria').style.display = 'none';
     document.getElementById('verTabla').style.display = 'block';
}
function ocultarGaleria(){
     document.getElementById('tablas').style.display = 'block';
     document.getElementById('galeria').style.display = 'none';
     document.getElementById('verGaleria').style.display = 'block';
     document.getElementById('verTabla').style.display = 'none';
}


